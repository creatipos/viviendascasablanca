<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Imagen_topig {

   function Imagen_topig($params){
      //Constructor, donde se supone que haremos algo con $params


echo 'ddd'.$params['p1'];


    
   }
}

?>